const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion
} = require("@whiskeysockets/baileys");

const qrcode = require("qrcode-terminal");

let sock = null;

async function startWhatsApp() {
  try {
    const { state, saveCreds } = await useMultiFileAuthState("./auth");
    const { version } = await fetchLatestBaileysVersion();

    sock = makeWASocket({
      version,
      auth: state,
      browser: ["Ubuntu", "Chrome", "22.04.4"]
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (qr) {
        console.log("📷 Escanea el QR:");
        qrcode.generate(qr, { small: true });
      }

      if (connection === "open") {
        console.log("✅ WhatsApp ONLINE");
      }

      if (connection === "close") {
        const reason =
          lastDisconnect?.error?.output?.statusCode;

        console.log("❌ Desconectado:", reason);

        if (reason !== DisconnectReason.loggedOut) {
          console.log("⚠️ Reconectando en 5 segundos...");
          setTimeout(() => startWhatsApp(), 100);
        } else {
          console.log("❌ Sesión cerrada, elimina auth y vuelve a escanear:");
          console.log("rm -rf auth && mkdir auth && node index.js");
        }
      }
    });

    try {
      require("./events")(sock);
    } catch (e) {
      console.log("ℹ️ events.js no cargado");
    }

  } catch (err) {
    console.log("Error:", err);
    setTimeout(() => startWhatsApp(), 100);
  }
}

function getSock() {
  return sock;
}

module.exports = {
  startWhatsApp,
  getSock
};
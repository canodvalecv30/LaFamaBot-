const { Markup } = require("telegraf");
const { getSock } = require("../whatsapp/connection");

module.exports = (bot) => {

bot.start((ctx) => {
  const name = ctx.from.first_name || "Usuario";

  ctx.replyWithMarkdown(
`♣ *AUTO BOT PANEL PRO* 🌉
╭─────────────────╮
┊ Usuario: *${name}*
┊ Estado: 🟢 ONLINE
╰─────────────────╯

Comandos:
/send numero mensaje
/spam numero cantidad mensaje
/ping
/info`,
Markup.inlineKeyboard([
[
Markup.button.callback("📋 MENU","menu"),
Markup.button.callback("⚡ PING","ping")
],
[
Markup.button.callback("ℹ️ INFO","info")
]
])
);
});

bot.action("menu",(ctx)=>{
ctx.reply(
`📋 MENU ACTIVO

/send numero mensaje
/spam numero cantidad mensaje
/ping
/info`
);
});

bot.action("ping",(ctx)=>{
ctx.reply("⚡ PONG");
});

bot.action("info",(ctx)=>{
ctx.reply("ℹ️ BOT ONLINE");
});

bot.command("ping",(ctx)=>{
ctx.reply("⚡ PONG");
});

bot.command("info",(ctx)=>{
ctx.reply("ℹ️ BOT ONLINE");
});

// ENVIAR MENSAJE
bot.command("send", async (ctx) => {

try {

const sock = getSock();

if (!sock) {
return ctx.reply("❌ WhatsApp no conectado");
}

const args = ctx.message.text.split(" ");

if (args.length < 3) {
return ctx.reply(
"Uso:\n/send 5215512345678 Hola mundo"
);
}

const numero = args[1].replace(/\D/g,"");
const mensaje = args.slice(2).join(" ");

await sock.sendMessage(
numero + "@s.whatsapp.net",
{
text: mensaje
}
);

ctx.reply("✅ Mensaje enviado");

} catch (e) {

console.log(e);

ctx.reply("❌ Error enviando mensaje");

}

});

// ENVÍO REPETIDO CONTROLADO
bot.command("spam", async (ctx) => {

try {

const sock = getSock();

if (!sock) {
return ctx.reply("❌ WhatsApp no conectado");
}

const args = ctx.message.text.split(" ");

if (args.length < 4) {
return ctx.reply(
"Uso:\n/spam 5215512345678 10 Hola mundo"
);
}

const numero = args[1].replace(/\D/g,"");
const cantidad = parseInt(args[2]);
const mensaje = args.slice(3).join(" ");

if (isNaN(cantidad) || cantidad < 1 || cantidad > 500) {
return ctx.reply("❌ Cantidad permitida: 1 a 500");
}

ctx.reply(`📤 Enviando ${cantidad} mensajes...`);

let enviados = 0;

for(let i = 0; i < cantidad; i++) {

try {

await sock.sendMessage(
numero + "@s.whatsapp.net",
{
text: mensaje
}
);

enviados++;

await new Promise(r => setTimeout(r, 100));

} catch(err) {

console.log(err);

}

}

ctx.reply(`✅ ${enviados} mensajes enviados`);

} catch(e) {

console.log(e);

ctx.reply("❌ Error");

}

});

};

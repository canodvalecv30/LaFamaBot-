module.exports = (bot) => {

  bot.action("ping", async (ctx) => {
    await ctx.answerCbQuery();
    ctx.reply("🏓 Pong");
  });

};

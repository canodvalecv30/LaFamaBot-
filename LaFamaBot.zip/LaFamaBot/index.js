const bot = require("./telegram/start");
const { startWhatsApp } = require("./whatsapp/connection");

bot.launch();

startWhatsApp();

console.log("🚀 LA FAMA BOT ONLINE");
process.on("unhandledRejection", (err) => {
console.log("❌ UnhandledRejection:", err);
});

process.on("uncaughtException", (err) => {
console.log("❌ UncaughtException:", err);
});


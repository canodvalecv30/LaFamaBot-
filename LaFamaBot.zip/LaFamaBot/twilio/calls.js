const twilio = require("twilio");

// 🔑 CREDENCIALES TWILIO
const accountSid = "TU_SID";
const authToken = "TU_TOKEN";

const client = twilio(accountSid, authToken);

// 📞 FUNCIÓN LLAMADA
async function makeCall(toNumber, urlTwiML) {
  try {
    const call = await client.calls.create({
      url: urlTwiML,
      to: `+${toNumber}`,
      from: "TU_NUMERO_TWILIO"
    });

    return call.sid;
  } catch (err) {
    console.log("❌ Error llamada:", err);
    return null;
  }
}

module.exports = { makeCall };
